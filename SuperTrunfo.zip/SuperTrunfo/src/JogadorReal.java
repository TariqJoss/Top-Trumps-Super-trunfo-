import java.util.Scanner;

public class JogadorReal extends Jogador{

	public JogadorReal(String nome) {
		super(nome);
	
	}
	
	@Override
	public String jogarTurno() {
        Scanner scan = new Scanner(System.in);
		System.out.println("\nEscreva o nome do atributo que deseja escolher como critério para este turno...");
		
		return scan.nextLine();
	}
}