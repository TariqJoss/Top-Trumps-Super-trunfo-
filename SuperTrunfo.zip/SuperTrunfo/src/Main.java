import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		String tema = "null";
		
		System.out.println("Bem-vindo ao SuperTrunfo Jogador!\n\n"
				         + "REGRAS: -As cartas serão distribuidas igualmente e aleatóriamente\n"
				         + "        -Cada turno os jogadores pegarão a primeira carta de seus montes e um deles escolherá um atributo sem que veja os atributos da carta adversária para competirem, o vencedor adicionara as duas cartas embaixo de seu monte\n"
				         + "        -O primeiro a escolher o atributo será aleatório, mas após o primeiro turno o vencedor do turno anterior fará a jogada\n"
				         + "        -Em caso de empates nos turnos, quem fez a escolha perderá o turno.\n"
				         + "        -Vence quem conseguir todas as cartas do baralho, fazendo com que seu oponente fique com 0 cartas no monte\n\n"
				         + "OBS: -AO SELECIONAR O TEMA/ATRIBUTO É IMPORTANTE ESCREVER O NOME EXATAMENTE COMO É MOSTRADO NA TELA PARA O USUÁRIO!!!\n\n"
				         + "Para começar, por favor digite o nome do tema com o qual gostaria de jogar:\n"
				         + "1- Dinossauros\n"
				         + "2- Carros\n"
				         + "3- Heróis\n"
				         + "4- Aviões\n"
				         + "5- Fate");
		
		while((!tema.equals("Dinossauros")) && (!tema.equals("Carros")) && (!tema.equals("Aviões")) && (!tema.equals("Heróis")) && (!tema.equals("Fate"))) {
			
			tema = leitor.nextLine();
			
			if((!tema.equals("Dinossauros")) && (!tema.equals("Carros")) && (!tema.equals("Aviões")) && (!tema.equals("Heróis")) && (!tema.equals("Fate"))) {
				
				System.out.println("\n" + tema + " não é um tema válido! Por favor selecione novamente.");
			}
		}

		
		if(tema.equals("Fate")) {
			System.out.println("\n*REGRA ESPECIAL*:\n" +
					           "Nesse tema o atributo 'noble phantasm' da carta 'EMIYA' terá seu valor sempre considerado como igual ao do 'noble phantasm' da carta adversária\n");
		}
		
		Jogo partida = new Jogo(tema, "Jogador", "Adversário");
		partida.Jogar();
		
		leitor.close();
	}
}