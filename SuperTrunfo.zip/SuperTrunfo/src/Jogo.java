import java.util.Collections;
import java.util.LinkedList;

public class Jogo {

	private Baralho baralho;
	private JogadorReal jogador;
	private Bot adversário;
	private Jogador vencedor;
	private Jogador vencedorDoTurno;
	private Jogador perdedorDoTurno;
	private Carta cartaDoJogador;
	private Carta cartaDoAdversário;
	private int contadorDeTurnos;
	
	/*O construtor coloca alguns valores iniciais para as variáveis pois algumas são importantes para
	  o código mesmo sem ter um valor "adequado", além disso ele já instância o personagem do usuário e o bot adversário
	  junto com a preparação do jogo em si, para que o método jogo fique responsável somente pela jogabilidade*/
	public Jogo(String tema, String nomeDoUsuário, String nomeDoAdversário) {
		this.contadorDeTurnos = 1;
		this.vencedor = null;
		this.vencedorDoTurno = new Jogador("ninguém");
		this.perdedorDoTurno = null;
		this.jogador = new JogadorReal(nomeDoUsuário);
		this.cartaDoJogador = null;
		this.adversário = new Bot(nomeDoAdversário);
		this.cartaDoAdversário = null;
		this.baralho = new Baralho(tema);
		this.baralho.carregar();
		this.baralho.embaralhar();
		this.baralho.distribuir(this.jogador, this.adversário);
		System.out.println("Partida iniciada com o tema: " + this.baralho.getTema());
		this.mostrarStatus();
	}
	
	
	public void mostrarVencedor() {
		if(vencedor == jogador) {
			
		    System.out.println("\nVITÓRIA!\n" +
		    		           "O vencedor é o " + this.vencedor.getNome() + "!");
		}
		
		else if(vencedor == adversário) {
			
		    System.out.println("\nDERROTA!\n" +
		    		           "O vencedor é o " + this.vencedor.getNome() + "!");
		}
	}
	
	public void mostrarStatus() {
		System.out.println("\nJogador: " + this.jogador.getMonte().size() + " cartas\n" + 
				           "Adversário: " + this.adversário.getMonte().size() + " cartas\n" +
				           "Venceu o último turno: " + this.vencedorDoTurno.getNome());
	}
	
	/*ESSA CLASE POSSUÍ BREVES EXPLICAÇÕES DURANTE O MÉTODO JOGAR DEVIDO À SUA "COMPLEXIDADE",
	  PODENDO ASSIM CAUSAR CONFUSÃO SEM ALGO PARA GUIAR O USUÁRIO*/
	public void Jogar( ) {
		//Variáveis para auxiliar no funcionamento do jogo
		String atributoEscolhido;
		Jogador variávelDeTransição;
		LinkedList<Jogador> randomizador = new LinkedList();
		
		//Randomizando quem vai primeiro
		randomizador.add(this.jogador);
		randomizador.add(this.jogador);
		randomizador.add(this.adversário);
		randomizador.add(this.adversário);
		Collections.shuffle(randomizador);
		
		vencedorDoTurno = randomizador.pollLast();
		if(vencedorDoTurno == jogador) {
		    perdedorDoTurno = adversário;
		}
		else {
		    perdedorDoTurno = jogador;
		}
		
		System.out.println("\n\n\nTurno " + this.contadorDeTurnos);
		System.out.println("\nO " + vencedorDoTurno.getNome() + " começa!");
	
		
		while(this.vencedor == null) {
			
			//Resetando o atributo escolhido/ Iniciando o atributoEscolhido
			atributoEscolhido = "null";
			
			//O selecionado como primeiro jogador fazendo a primeira jogada / Vencedor do turno anterior fazendo a jogada
			if(vencedorDoTurno == this.jogador) {
				
				this.cartaDoJogador = this.jogador.getMonte().pegarDoTopo();
				System.out.println("\nSua carta:\n\n" + this.cartaDoJogador.toString());
				
				//Verificando se o jogador escreveu o nome do atributo corretamente
				while((!atributoEscolhido.equals(this.cartaDoJogador.getAtributo1().getNome())) && (!atributoEscolhido.equals(this.cartaDoJogador.getAtributo2().getNome())) && (!atributoEscolhido.equals(this.cartaDoJogador.getAtributo3().getNome())) && (!atributoEscolhido.equals(this.cartaDoJogador.getAtributo4().getNome())))	{
					
					atributoEscolhido = this.jogador.jogarTurno();
					
					if((!atributoEscolhido.equals(this.cartaDoJogador.getAtributo1().getNome())) && (!atributoEscolhido.equals(this.cartaDoJogador.getAtributo2().getNome())) && (!atributoEscolhido.equals(this.cartaDoJogador.getAtributo3().getNome())) && (!atributoEscolhido.equals(this.cartaDoJogador.getAtributo4().getNome())))	{
						
						System.out.println("\n" + atributoEscolhido + " não é um atributo válido! Por favor selecione novamente.\n");
					}
				}
				System.out.println("\nO jogador escolheu " + atributoEscolhido + " como critério para este turno!");
				
				this.cartaDoAdversário = this.adversário.getMonte().pegarDoTopo();
				System.out.println("\nCarta do Adversário:\n\n" + this.cartaDoAdversário.toString());
			}
			
			else {
				
				this.cartaDoAdversário = this.adversário.getMonte().pegarDoTopo();
				System.out.println("\nCarta do Adversário:\n\n" + this.cartaDoAdversário.toString());
				
				atributoEscolhido = this.adversário.jogarTurno();
				System.out.println("\nO adversário escolheu " + atributoEscolhido + " como critério para este turno!");
				
				this.cartaDoJogador = this.jogador.getMonte().pegarDoTopo();
				System.out.println("\nSua carta:\n\n" + this.cartaDoJogador.toString());
			}
			
			//Calculando os resultados da jogada
			
			//Se alguém vencer com o SuperTrunfo independente do atributo
			if((this.cartaDoAdversário.getSuperTrunfo().equals("true")) && ((!this.cartaDoJogador.getCódigo().equals("A1")) && (!this.cartaDoJogador.getCódigo().equals("A2")) && (!this.cartaDoJogador.getCódigo().equals("A3")) && (!this.cartaDoJogador.getCódigo().equals("A4")) && (!this.cartaDoJogador.getCódigo().equals("A5")) && (!this.cartaDoJogador.getCódigo().equals("A6")) && (!this.cartaDoJogador.getCódigo().equals("A7")) && (!this.cartaDoJogador.getCódigo().equals("A8")))) {
				
				System.out.println("\nO adversário venceu o turno com o SuperTrunfo!");
				this.vencedorDoTurno = this.adversário;
				this.perdedorDoTurno = this.jogador;
						
				this.adversário.getMonte().addFirst(this.cartaDoJogador);
				this.adversário.getMonte().addFirst(this.cartaDoAdversário);
			}
				
			else if((this.cartaDoJogador.getSuperTrunfo().equals("true")) && ((!this.cartaDoAdversário.getCódigo().equals("A1")) && (!this.cartaDoAdversário.getCódigo().equals("A2")) && (!this.cartaDoAdversário.getCódigo().equals("A3")) && (!this.cartaDoAdversário.getCódigo().equals("A4")) && (!this.cartaDoAdversário.getCódigo().equals("A5")) && (!this.cartaDoAdversário.getCódigo().equals("A6")) && (!this.cartaDoAdversário.getCódigo().equals("A7")) && (!this.cartaDoAdversário.getCódigo().equals("A8")))) {

					System.out.println("\nO jogador venceu o turno com o SuperTrunfo!");
					this.vencedorDoTurno = this.jogador;
					this.perdedorDoTurno = this.adversário;
						
					this.jogador.getMonte().addFirst(this.cartaDoAdversário);
					this.jogador.getMonte().addFirst(this.cartaDoJogador);
			}
			
			//Quando a vitória depender do atibuto
			
			//Atributo 1
			else if(atributoEscolhido.equals(this.cartaDoJogador.getAtributo1().getNome())) {
					
				//Quando o Atributo do jogador é maior
				if(this.cartaDoJogador.getAtributo1().getValor() > this.cartaDoAdversário.getAtributo1().getValor()) {
						
					System.out.println("\nO jogador venceu o turno!");
					this.vencedorDoTurno = this.jogador;
					this.perdedorDoTurno = this.adversário;
						
					this.jogador.getMonte().addFirst(this.cartaDoAdversário);
					this.jogador.getMonte().addFirst(this.cartaDoJogador);
				}
					
				//Quando o Atributo do adversário é maior
				else if(this.cartaDoJogador.getAtributo1().getValor() < this.cartaDoAdversário.getAtributo1().getValor()) {
						
					System.out.println("\nO adversário venceu o turno!");
					this.vencedorDoTurno = this.adversário;
					this.perdedorDoTurno = this.jogador;
							
					this.adversário.getMonte().addFirst(this.cartaDoJogador);
					this.adversário.getMonte().addFirst(this.cartaDoAdversário);
				}
				
				//Quando empata, quem fez a jogada perde
				else {
					
					if(perdedorDoTurno == jogador) {
						
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					}
					else {
						
						perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					}
					
					System.out.println("\nEmpate: O " + perdedorDoTurno.getNome() + " venceu!");
					variávelDeTransição = vencedorDoTurno;
					this.vencedorDoTurno = perdedorDoTurno;
					this.perdedorDoTurno = variávelDeTransição;
				}
			}
			
			//Atributo 2
			else if(atributoEscolhido.equals(this.cartaDoJogador.getAtributo2().getNome())) {
				
				if(this.cartaDoJogador.getAtributo2().getValor() > this.cartaDoAdversário.getAtributo2().getValor()) {
						
					System.out.println("\nO jogador venceu o turno!");
					this.vencedorDoTurno = this.jogador;
					this.perdedorDoTurno = this.adversário;
						
					this.jogador.getMonte().addFirst(this.cartaDoAdversário);
					this.jogador.getMonte().addFirst(this.cartaDoJogador);
				}
					
				else if(this.cartaDoJogador.getAtributo2().getValor() < this.cartaDoAdversário.getAtributo2().getValor()) {
						
					System.out.println("\nO adversário venceu o turno!");
					this.vencedorDoTurno = this.adversário;
					this.perdedorDoTurno = this.jogador;
							
					this.adversário.getMonte().addFirst(this.cartaDoJogador);
					this.adversário.getMonte().addFirst(this.cartaDoAdversário);
				}
	              
	            else {
					
					if(perdedorDoTurno == jogador) {
						
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					}
					else {
						
						perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					}
					
					System.out.println("\nEmpate: O " + perdedorDoTurno.getNome() + " venceu!");
					variávelDeTransição = vencedorDoTurno;
					this.vencedorDoTurno = perdedorDoTurno;
					this.perdedorDoTurno = variávelDeTransição;
				}
			}
			
			//Atributo 3
			else if(atributoEscolhido.equals(this.cartaDoJogador.getAtributo3().getNome())) {
				
				if(this.cartaDoJogador.getAtributo3().getValor() > this.cartaDoAdversário.getAtributo3().getValor()) {
						
					System.out.println("\nO jogador venceu o turno!");
					this.vencedorDoTurno = this.jogador;
					this.perdedorDoTurno = this.adversário;
						
					this.jogador.getMonte().addFirst(this.cartaDoAdversário);
					this.jogador.getMonte().addFirst(this.cartaDoJogador);
				}
					
				else if(this.cartaDoJogador.getAtributo3().getValor() < this.cartaDoAdversário.getAtributo3().getValor()) {
						
					System.out.println("\nO adversário venceu o turno!");
					this.vencedorDoTurno = this.adversário;
					this.perdedorDoTurno = this.jogador;
							
					this.adversário.getMonte().addFirst(this.cartaDoJogador);
					this.adversário.getMonte().addFirst(this.cartaDoAdversário);
				}
	            
	            else {
					
					if(perdedorDoTurno == jogador) {
						
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					}
					else {
						
						perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					}
					
					System.out.println("\nEmpate: O " + perdedorDoTurno.getNome() + " venceu!");
					variávelDeTransição = vencedorDoTurno;
					this.vencedorDoTurno = perdedorDoTurno;
					this.perdedorDoTurno = variávelDeTransição;
				}
			}
			
			//Atributo 4
	        else if(atributoEscolhido.equals(this.cartaDoJogador.getAtributo4().getNome())) {
				
	        	//Regra especial do tema Fate
	        	if((this.cartaDoJogador.getNome().equals("EMIYA")) || (this.cartaDoAdversário.getNome().equals("EMIYA"))) {
					
                    if(perdedorDoTurno == jogador) {
						
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					}
					else {
						
						perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					}
					
					System.out.println("\nEmpate pelo Noble Phantasm de EMIYA!: O " + perdedorDoTurno.getNome() + " venceu!");
					variávelDeTransição = vencedorDoTurno;
					this.vencedorDoTurno = perdedorDoTurno;
					this.perdedorDoTurno = variávelDeTransição;
				}
	        	//Fim da regra especial
	        	
	            else if(this.cartaDoJogador.getAtributo4().getValor() > this.cartaDoAdversário.getAtributo4().getValor()) {
						
					System.out.println("\nO jogador venceu o turno!");
					this.vencedorDoTurno = this.jogador;
					this.perdedorDoTurno = this.adversário;
						
					this.jogador.getMonte().addFirst(this.cartaDoAdversário);
					this.jogador.getMonte().addFirst(this.cartaDoJogador);
				}
					
				else if(this.cartaDoJogador.getAtributo4().getValor() < this.cartaDoAdversário.getAtributo4().getValor()) {
						
					System.out.println("\nO adversário venceu o turno!");
					this.vencedorDoTurno = this.adversário;
					this.perdedorDoTurno = this.jogador;
							
					this.adversário.getMonte().addFirst(this.cartaDoJogador);
					this.adversário.getMonte().addFirst(this.cartaDoAdversário);
				}
				
	            else {
					
					if(perdedorDoTurno == jogador) {
						
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					}
					else {
						
						perdedorDoTurno.getMonte().addFirst(this.cartaDoJogador);
					    perdedorDoTurno.getMonte().addFirst(this.cartaDoAdversário);
					}
					
					System.out.println("\nEmpate: O " + perdedorDoTurno.getNome() + " venceu!");
					variávelDeTransição = vencedorDoTurno;
					this.vencedorDoTurno = perdedorDoTurno;
					this.perdedorDoTurno = variávelDeTransição;
				}
			}
			
			//Mostrando como ficou a partida após esse turno
			this.mostrarStatus();
			
			//Verificando se alguém venceu neste turno
			if(this.jogador.getMonte().size() == 0) {
				this.vencedor = this.adversário;
			}
			else if(this.adversário.getMonte().size() == 0) {
				this.vencedor = this.jogador;
			}
			
			//Se alguém venceu o jogo dirá quem e a partida será encerrada
			if(this.vencedor != null) {
				
			    this.mostrarVencedor();
			    break;
			}
			
			this.contadorDeTurnos++;
			System.out.println("\n\n\nTurno " + this.contadorDeTurnos);
			System.out.println("\nÉ a vez do " + vencedorDoTurno.getNome() + "!");
		}
	}


	public Jogador getVencedor() {
		return vencedor;
	}

	public void setVencedor(Jogador vencedor) {
		this.vencedor = vencedor;
	}

	public Jogador getJogador() {
		return jogador;
	}

	public Jogador getAdversário() {
		return adversário;
	}

	public Jogador getVencedorDoTurno() {
		return vencedorDoTurno;
	}

	public void setVencedorDoTurno(Jogador vencedorDoTurno) {
		this.vencedorDoTurno = vencedorDoTurno;
	}

	public Jogador getPerdedorDoTurno() {
		return perdedorDoTurno;
	}

	public void setPerdedorDoTurno(Jogador perdedorDoTurno) {
		this.perdedorDoTurno = perdedorDoTurno;
	}

	public int getContadorDeTurnos() {
		return contadorDeTurnos;
	}

	public void setContadorDeTurnos(int contadorDeTurnos) {
		this.contadorDeTurnos = contadorDeTurnos;
	}
}
