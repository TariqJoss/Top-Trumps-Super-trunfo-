import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.io.*;

public class Baralho extends LinkedList<Carta>{

	private String tema;

	
	public Baralho(String tema) {
		this.tema = tema;
	}

	
	public void carregar() {
		Double convertorParaDouble = null;
		double valor1;
		double valor2;
		double valor3;
		double valor4;
		FileInputStream fluxo = null;
        InputStreamReader leitor = null;
        BufferedReader leitorComBuffer = null;
        String[] carta;
        String linha;
		switch(tema) {
		    case "Dinossauros":
		    	try {
		    	    fluxo = new FileInputStream("dinossauros.csv");
		    	    leitor = new InputStreamReader(fluxo);
		    	    leitorComBuffer = new BufferedReader(leitor);
		    	    leitorComBuffer.readLine();
		    	    
		    	    linha = leitorComBuffer.readLine();
		    	    
		    	    while (linha != null) {
		    	    	carta = linha.split(",");
		    	    	valor1 = convertorParaDouble.parseDouble(carta[2]);
		    	    	valor2 = convertorParaDouble.parseDouble(carta[3]);
		    	    	valor3 = convertorParaDouble.parseDouble(carta[4]);
		    	    	valor4 = convertorParaDouble.parseDouble(carta[5]);
		    	    	this.add(new Carta(carta[0], carta[1], valor1, valor2, valor3, valor4, "altura", "comprimento", "peso", "viveu há", "m", "m", "kg", "milhões de anos", carta[6]));
		    	    	linha = leitorComBuffer.readLine();
		    	    	}

		        }catch(FileNotFoundException e) {
		        	e.printStackTrace();
		        	
		        }catch(IOException i) {
		        	i.printStackTrace();
		        }
		    	finally {
		    		try {
		        	leitorComBuffer.close();
		        	leitor.close();
		        	fluxo.close();
		        	
		    		}catch(IOException i) {
		    	    	i.printStackTrace();
		    	    }
		        }
		    	break;
		    	
		    case "Aviões":
		    	try {
		    	    fluxo = new FileInputStream("avioes.csv");
		    	    leitor = new InputStreamReader(fluxo);
		    	    leitorComBuffer = new BufferedReader(leitor);
		    	    leitorComBuffer.readLine();
		    	    
		    	    linha = leitorComBuffer.readLine();
		    	    
		    	    while (linha != null) {
		    	    	carta = linha.split(",");
		    	    	valor1 = convertorParaDouble.parseDouble(carta[2]);
		    	    	valor2 = convertorParaDouble.parseDouble(carta[3]);
		    	    	valor3 = convertorParaDouble.parseDouble(carta[4]);
		    	    	valor4 = convertorParaDouble.parseDouble(carta[5]);
		    	    	this.add(new Carta(carta[0], carta[1], valor1, valor2, valor3, valor4, "velocidade", "altitude", "comprimento", "altura", "km/h", "m", "m", "m", carta[6]));
		    	    	linha = leitorComBuffer.readLine();
		    	    	}

		        }catch(FileNotFoundException e) {
		        	e.printStackTrace();
		        	
		        }catch(IOException i) {
		        	i.printStackTrace();
		        }
		    	finally {
		    		try {
		        	leitorComBuffer.close();
		        	leitor.close();
		        	fluxo.close();
		        	
		    		}catch(IOException i) {
		    	    	i.printStackTrace();
		    	    }
		        }
		    	break;
		    	
		    case "Heróis":
		    	try {
		    	    fluxo = new FileInputStream("herois.csv");
		    	    leitor = new InputStreamReader(fluxo);
		    	    leitorComBuffer = new BufferedReader(leitor);
		    	    leitorComBuffer.readLine();
		    	    
		    	    linha = leitorComBuffer.readLine();
		    	    
		    	    while (linha != null) {
		    	    	carta = linha.split(",");
		    	    	valor1 = convertorParaDouble.parseDouble(carta[2]);
		    	    	valor2 = convertorParaDouble.parseDouble(carta[3]);
		    	    	valor3 = convertorParaDouble.parseDouble(carta[4]);
		    	    	valor4 = convertorParaDouble.parseDouble(carta[5]);
		    	    	this.add(new Carta(carta[0], carta[1], valor1, valor2, valor3, valor4, "velocidade", "inteligência", "agilidade", "força", " ", " ", " ", " ", carta[6]));
		    	    	linha = leitorComBuffer.readLine();
		    	    	}

		        }catch(FileNotFoundException e) {
		        	e.printStackTrace();
		        	
		        }catch(IOException i) {
		        	i.printStackTrace();
		        }
		    	finally {
		    		try {
		        	leitorComBuffer.close();
		        	leitor.close();
		        	fluxo.close();
		        	
		    		}catch(IOException i) {
		    	    	i.printStackTrace();
		    	    }
		        }
		    	break;
		    	
		    case "Carros":
		    	try {
		    	    fluxo = new FileInputStream("carros.csv");
		    	    leitor = new InputStreamReader(fluxo);
		    	    leitorComBuffer = new BufferedReader(leitor);
		    	    leitorComBuffer.readLine();
		    	    
		    	    linha = leitorComBuffer.readLine();
		    	    
		    	    while (linha != null) {
		    	    	carta = linha.split(",");
		    	    	valor1 = convertorParaDouble.parseDouble(carta[2]);
		    	    	valor2 = convertorParaDouble.parseDouble(carta[3]);
		    	    	valor3 = convertorParaDouble.parseDouble(carta[4]);
		    	    	valor4 = convertorParaDouble.parseDouble(carta[5]);
		    	    	this.add(new Carta(carta[0], carta[1], valor1, valor2, valor3, valor4, "cilindradas", "potência", "velocidade", "comprimento", "cilindradas", "cv", "km/h", "m", carta[6]));
		    	    	linha = leitorComBuffer.readLine();
		    	    	}

		        }catch(FileNotFoundException e) {
		        	e.printStackTrace();
		        	
		        }catch(IOException i) {
		        	i.printStackTrace();
		        }
		    	finally {
		    		try {
		        	leitorComBuffer.close();
		        	leitor.close();
		        	fluxo.close();
		        	
		    		}catch(IOException i) {
		    	    	i.printStackTrace();
		    	    }
		        }
		    	break;
		    	
		    case "Fate":
		    	try {
		    	    fluxo = new FileInputStream("fate.csv");
		    	    leitor = new InputStreamReader(fluxo);
		    	    leitorComBuffer = new BufferedReader(leitor);
		    	    leitorComBuffer.readLine();
		    	    
		    	    linha = leitorComBuffer.readLine();
		    	    
		    	    while (linha != null) {
		    	    	carta = linha.split(",");
		    	    	valor1 = convertorParaDouble.parseDouble(carta[2]);
		    	    	valor2 = convertorParaDouble.parseDouble(carta[3]);
		    	    	valor3 = convertorParaDouble.parseDouble(carta[4]);
		    	    	valor4 = convertorParaDouble.parseDouble(carta[5]);
		    	    	this.add(new Carta(carta[0], carta[1], valor1, valor2, valor3, valor4, "força", "agilidade", "resistência", "noble phantasm", " ", " ", " ", " ", carta[6]));
		    	    	linha = leitorComBuffer.readLine();
		    	    	}

		        }catch(FileNotFoundException e) {
		        	e.printStackTrace();
		        	
		        }catch(IOException i) {
		        	i.printStackTrace();
		        }
		    	finally {
		    		try {
		        	leitorComBuffer.close();
		        	leitor.close();
		        	fluxo.close();
		        	
		    		}catch(IOException i) {
		    	    	i.printStackTrace();
		    	    }
		        }
		    	break;
		}
	}
	
    public void embaralhar() {
		Collections.shuffle(this);
	}
	
    public void distribuir(Jogador jogador, Jogador adversário) {
		int índiceDeJogador = 0;
		Iterator<Carta> iterator = this.iterator();
		
		while (iterator.hasNext()) {
			
			if (jogador.getMonte() == null) {
				jogador.setMonte(new Baralho(this.tema));
			}
			if (adversário.getMonte() == null) {
				adversário.setMonte(new Baralho(this.tema));
			}
			
			if (índiceDeJogador == 0) {
				jogador.getMonte().add(iterator.next());
				iterator.remove();
			    }
			
			if (índiceDeJogador == 1) {
				adversário.getMonte().add(iterator.next());
				iterator.remove();
				}
			
			índiceDeJogador = (índiceDeJogador + 1) % 2;
 		}
	}
    
    public void listarCartas() {
		System.out.println(this);
	}
    
    public Carta pegarDoTopo() {
		if ( this.peekLast() != null) {
			return this.pollLast();
		}
		else {
			System.out.println("Baralho vazio!");
			return null;
		}
	}
    
    
	public String getTema() {
		return tema;
	}

	public void setTema(String tema) {
		this.tema = tema;
	}
}