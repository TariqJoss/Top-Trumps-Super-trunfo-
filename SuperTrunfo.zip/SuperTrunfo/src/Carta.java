public class Carta {

	private String nome;
	private String código;
    private Atributo atributo1;
    private Atributo atributo2;
    private Atributo atributo3;
    private Atributo atributo4;
    private String superTrunfo;

    public Carta(String nome, String código, double valor1, double valor2, double valor3, double valor4,
    		     String nome1, String nome2, String nome3, String nome4, String unidade1, String unidade2, String unidade3, String unidade4,
    		     String superTrunfo) {
        
    	this.nome = nome;
    	this.código = código;
    	this.superTrunfo = superTrunfo;
    	this.atributo1 = new Atributo(nome1, unidade1, valor1);
    	this.atributo2 = new Atributo(nome2, unidade2, valor2);
    	this.atributo3 = new Atributo(nome3, unidade3, valor3);
    	this.atributo4 = new Atributo(nome4, unidade4, valor4);
    }
    
    
    public String getNome() {
		return nome;
	}

	public String getCódigo() {
		return código;
	}

	public Atributo getAtributo1() {
		return atributo1;
	}

	public Atributo getAtributo2() {
		return atributo2;
	}

	public Atributo getAtributo3() {
		return atributo3;
	}

	public Atributo getAtributo4() {
		return atributo4;
	}

	public String getSuperTrunfo() {
		return superTrunfo;
	}


	@Override
    public String toString() {
    	String retorno;
    	if(this.superTrunfo.equals("false")) {
    	       retorno = this.código + " " + this.nome + "\n" + this.atributo1.toString() + "\n" + this.atributo2.toString() + "\n"
    			         + this.atributo3.toString() + "\n" + this.atributo4.toString();
    	}else {
    		retorno = this.código + " " + this.nome + "\n" + this.atributo1.toString() + "\n" + this.atributo2.toString() + "\n"
			         + this.atributo3.toString() + "\n" + this.atributo4.toString() + "\n" + "SuperTrunfo!";
    	}
        return retorno;
    }
}
