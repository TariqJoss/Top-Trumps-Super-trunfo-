import java.util.Collections;
import java.util.LinkedList;

public class Bot extends Jogador{
	
	public Bot(String nome){
		super(nome);
		
	}	
	
	@Override
	public String jogarTurno() {
		
		LinkedList<String> atributos = new LinkedList<String>();
		atributos.add("atributo1");
		atributos.add("atributo2");
		atributos.add("atributo3");
		atributos.add("atributo4");
		
		Collections.shuffle(atributos);
		
		switch(this.getMonte().getTema()) {
		
		case("Dinossauros"):
			if(atributos.pollLast() == "atributo1") return "altura";
			else if(atributos.pollLast() == "atributo2") return "comprimento";
			else if(atributos.pollLast() == "atributo3") return "peso";
			else return "viveu há";
		
		case("Aviões"):
			if(atributos.pollLast() == "atributo1") return "velocidade";
			else if(atributos.pollLast() == "atributo2") return "altitude";
			else if(atributos.pollLast() == "atributo3") return "comprimento";
			else return "altura";
		
		case("Heróis"):
			if(atributos.pollLast() == "atributo1") return "velocidade";
			else if(atributos.pollLast() == "atributo2") return "inteligência";
			else if(atributos.pollLast() == "atributo3") return "agilidade";
			else return "força";
		
		case("Carros"):
			if(atributos.pollLast() == "atributo1") return "cilindradas";
			else if(atributos.pollLast() == "atributo2") return "potência";
			else if(atributos.pollLast() == "atributo3") return "velocidade";
			else return "comprimento";
		
		case("Fate"):
			if(atributos.pollLast() == "atributo1") return "força";
			else if(atributos.pollLast() == "atributo2") return "agilidade";
			else if(atributos.pollLast() == "atributo3") return "resistência";
			else return "noble phantasm";
		}
		
		return "null";
	}
}