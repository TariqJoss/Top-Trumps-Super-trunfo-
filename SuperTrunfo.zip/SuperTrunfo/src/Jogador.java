//CLASSE ABSTRATA DE JOGADOR
public class Jogador {

	private String nome;
	private Baralho monte;
	private String nomeDoAtributoSelecionado;
	
	
	public Jogador(String nome) {
		this.nome = nome;
	}
	
	
	public String jogarTurno() {
		
		return  nomeDoAtributoSelecionado;
	}
	
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Baralho getMonte() {
		return monte;
	}

	public void setMonte(Baralho monte) {
		this.monte = monte;
	}

	public String getNomeDoAtributoSelecionado() {
		return nomeDoAtributoSelecionado;
	}
	
	public void setNomeDoAtributoSelecionado(String nomeDoAtributoSelecionado) {
		this.nomeDoAtributoSelecionado = nomeDoAtributoSelecionado;
	}
}
